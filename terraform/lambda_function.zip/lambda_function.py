import json
import os
import requests
import boto3

sns_client = boto3.client('sns')
api_key = os.environ['ALPHA_VANTAGE_API_KEY']
sns_topic_arn = os.environ['SNS_TOPIC_ARN']
symbols = os.environ['STOCK_SYMBOLS'].split(",")  # Read multiple symbols from an environment variable

def lambda_handler(event, context):
    alerts = []
    
    for symbol in symbols:
        url = f"https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol={symbol}&apikey={api_key}"
        response = requests.get(url)
        data = response.json()
        
        if "Global Quote" in data:
            stock_data = data["Global Quote"]
            price = stock_data.get("05. price", "N/A")
            change_percent = stock_data.get("10. change percent", "N/A")
            
            alert = f"Stock: {symbol}, Price: {price}, Change: {change_percent}"
            alerts.append(alert)
        else:
            alerts.append(f"Error fetching data for {symbol}")
    
    # Combine all alerts into one message
    message = "\n".join(alerts)
    sns_client.publish(TopicArn=sns_topic_arn, Message=message, Subject="Stock Market Updates")
    
    return {"statusCode": 200, "body": json.dumps({"message": message})}